-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2025 at 03:23 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_perpus`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `id_buku` int(10) NOT NULL,
  `Judul buku` varchar(255) NOT NULL,
  `Penulis` varchar(255) NOT NULL,
  `thTerbit` int(4) NOT NULL,
  `isbn` varchar(20) NOT NULL,
  `id_Kategori` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id_buku`, `Judul buku`, `Penulis`, `thTerbit`, `isbn`, `id_Kategori`) VALUES
(1, 'th', 'etgz', 2024, '345', 1),
(2, 'ggg', 'fghg', 2024, '2223', 2),
(3, 'sunda', 'mia', 2019, '333', 2323);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id_user` int(8) NOT NULL,
  `namaDepan` varchar(15) NOT NULL,
  `namaBelakang` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `userName` varchar(15) NOT NULL,
  `password` varchar(8) NOT NULL,
  `level` enum('Petugas','Guru','Siswa','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id_user`, `namaDepan`, `namaBelakang`, `email`, `userName`, `password`, `level`) VALUES
(123, 'miaw', 'marlina', 'marlina44@gmail.com', 'miaw marlina', '4882', 'Guru'),
(124, 'maya', 'Maulina', 'miamaulina19@gmail.com', 'Mia Maulina', '4882', 'Siswa'),
(1234, 'lina', 'marlina', 'marlina22@gmail.com', 'lina marlina', '4882', 'Petugas');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_anggota`
--

CREATE TABLE `tbl_anggota` (
  `id_siswa` int(10) NOT NULL,
  `namaSiswa` varchar(15) NOT NULL,
  `Kelas` varchar(10) NOT NULL,
  `Email` varchar(25) NOT NULL,
  `jenisKelamin` varchar(10) NOT NULL,
  `programKeahlian` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_anggota`
--

INSERT INTO `tbl_anggota` (`id_siswa`, `namaSiswa`, `Kelas`, `Email`, `jenisKelamin`, `programKeahlian`) VALUES
(2, 'mi', 'Perempuan', 'XI', 'PPLG', '@gmail'),
(1, 'mia', 'Perempuan', 'xi', 'PPLG', '342@gmail.com'),
(3, 'mia maulina', 'Perempuan', 'xi', 'PPLG', '19@gmail.com'),
(2, 'mi', 'Perempuan', 'XI', 'PPLG', '@gmail'),
(1, 'mia', 'Perempuan', 'xi', 'PPLG', '342@gmail.com'),
(3, 'mia maulina', 'Perempuan', 'xi', 'PPLG', '19@gmail.com'),
(2, 'mi', 'Perempuan', 'XI', 'PPLG', '@gmail'),
(1, 'mia', 'Perempuan', 'xi', 'PPLG', '342@gmail.com'),
(3, 'mia maulina', 'Perempuan', 'xi', 'PPLG', '19@gmail.com'),
(2, 'mi', 'Perempuan', 'XI', 'PPLG', '@gmail'),
(1, 'mia', 'Perempuan', 'xi', 'PPLG', '342@gmail.com'),
(3, 'mia maulina', 'Perempuan', 'xi', 'PPLG', '19@gmail.com'),
(2, 'mi', 'Perempuan', 'XI', 'PPLG', '@gmail'),
(1, 'mia', 'Perempuan', 'xi', 'PPLG', '342@gmail.com'),
(3, 'mia maulina', 'Perempuan', 'xi', 'PPLG', '19@gmail.com'),
(2, 'mi', 'Perempuan', 'XI', 'PPLG', '@gmail'),
(1, 'mia', 'Perempuan', 'xi', 'PPLG', '342@gmail.com'),
(3, 'mia maulina', 'Perempuan', 'xi', 'PPLG', '19@gmail.com'),
(2, 'mi', 'Perempuan', 'XI', 'PPLG', '@gmail'),
(1, 'mia', 'Perempuan', 'xi', 'PPLG', '342@gmail.com'),
(3, 'mia maulina', 'Perempuan', 'xi', 'PPLG', '19@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kategori`
--

CREATE TABLE `tbl_kategori` (
  `id_Kategori` int(10) NOT NULL,
  `Katagori` varchar(100) NOT NULL,
  `Deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_kategori`
--

INSERT INTO `tbl_kategori` (`id_Kategori`, `Katagori`, `Deskripsi`) VALUES
(1, 'Buku Pelajaran', ''),
(2, 'Buku Reprensi', ''),
(3, 'Buku Agama', ''),
(4, 'Novel dan Cerita', ''),
(5, 'Buku Keterampilan', ''),
(6, 'Biografi dan Sejarah', ''),
(7, 'Sain dan Teknologi', ''),
(8, 'Buku Sastra', ''),
(9, 'Buku Anak-anak', ''),
(10, 'Buku Kesehatan', ''),
(11, 'Buku Panduan Belajar', ''),
(12, 'Majalah dan Jurnal', ''),
(13, 'apt yyy', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_peminjaman`
--

CREATE TABLE `tbl_peminjaman` (
  `id_peminjam` int(10) NOT NULL,
  `id_buku` int(15) NOT NULL,
  `id_siswa` int(10) NOT NULL,
  `tgl_pinjam` date NOT NULL,
  `tgl_bts_pengembalian` date NOT NULL,
  `tgl_kembali` date NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_peminjaman`
--

INSERT INTO `tbl_peminjaman` (`id_peminjam`, `id_buku`, `id_siswa`, `tgl_pinjam`, `tgl_bts_pengembalian`, `tgl_kembali`, `status`) VALUES
(1, 23, 19, '2025-05-07', '2025-05-14', '2025-07-10', 'Kembali'),
(2, 45, 12, '2025-06-04', '2025-06-11', '2025-06-11', 'pinjam'),
(3, 67, 13, '2025-06-04', '2025-06-11', '2025-06-11', 'pinjam');

--
-- Triggers `tbl_peminjaman`
--
DELIMITER $$
CREATE TRIGGER `insert_status_pinjam` BEFORE INSERT ON `tbl_peminjaman` FOR EACH ROW BEGIN
   if new.status IS NULL THEN
      SET NEW.status = 'Pinjam';
   END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_status_pengembalian` BEFORE UPDATE ON `tbl_peminjaman` FOR EACH ROW BEGIN
   IF NEW.tgl_kembali IS NOT NULL AND NEW.tgl_kembali > NEW.tgl_pinjam THEN
      SET NEW.status = 'Kembali';
   END IF;
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id_buku`),
  ADD KEY `id_Kategori` (`id_Kategori`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `tbl_kategori`
--
ALTER TABLE `tbl_kategori`
  ADD PRIMARY KEY (`id_Kategori`);

--
-- Indexes for table `tbl_peminjaman`
--
ALTER TABLE `tbl_peminjaman`
  ADD PRIMARY KEY (`id_peminjam`),
  ADD KEY `id_buku` (`id_buku`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
