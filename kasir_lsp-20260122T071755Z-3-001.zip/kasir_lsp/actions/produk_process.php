<?php
session_start();

// Cek status login
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: ../index.php");
    exit;
}

require_once '../includes/koneksi.php';

// Pastikan hanya Administrator yang bisa melanjutkan proses CRUD
if ($_SESSION['role'] !== 'Administrator') {
    $_SESSION['status_produk'] = "Error: Anda tidak memiliki hak akses untuk melakukan aksi ini.";
    header("Location: ../pages/produk.php");
    exit;
}

// Ambil aksi yang diminta (tambah, edit, atau delete)
$action = $_REQUEST['action'] ?? '';
$status = ''; // Variabel untuk menyimpan pesan status

try {
    if ($action == 'tambah') {
        // Logika Tambah Produk
        $nama_produk = trim($_POST['nama_produk']);
        $harga = $_POST['harga'];
        $stok = $_POST['stok'];

        $sql = "INSERT INTO produk (NamaProduk, Harga, Stok) VALUES (?, ?, ?)";
        $stmt = $koneksi->prepare($sql);
        $stmt->bind_param("sdi", $nama_produk, $harga, $stok); // s=string, d=decimal, i=integer

        if ($stmt->execute()) {
            $status = "Sukses: Produk '{$nama_produk}' berhasil ditambahkan!";
        } else {
            throw new Exception("Gagal menyimpan data ke database.");
        }

        $stmt->close();

    } elseif ($action == 'edit') {
        // Logika Edit Produk
        $id = $_POST['produk_id'];
        $nama_produk = trim($_POST['nama_produk']);
        $harga = $_POST['harga'];
        $stok = $_POST['stok'];

        $sql = "UPDATE produk SET NamaProduk = ?, Harga = ?, Stok = ? WHERE ProdukID = ?";
        $stmt = $koneksi->prepare($sql);
        $stmt->bind_param("sdii", $nama_produk, $harga, $stok, $id);

        if ($stmt->execute()) {
            $status = "Sukses: Produk ID {$id} berhasil diupdate!";
        } else {
            throw new Exception("Gagal mengupdate data produk.");
        }

        $stmt->close();

    } elseif ($action == 'delete') {
        // Logika Hapus Produk
        $id = $_GET['id'];

        $sql = "DELETE FROM produk WHERE ProdukID = ?";
        $stmt = $koneksi->prepare($sql);
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            $status = "Sukses: Produk ID {$id} berhasil dihapus!";
        } else {
            throw new Exception("Gagal menghapus produk. Pastikan produk ini tidak terkait dengan data penjualan!");
        }

        $stmt->close();
    }

} catch (Exception $e) {
    // Tangani error umum
    $status = "Error: " . $e->getMessage();
}

// Simpan status ke sesi untuk ditampilkan di halaman produk.php
$_SESSION['status_produk'] = $status;

// Redirect kembali ke halaman produk
$koneksi->close();
header("Location: ../pages/produk.php");
exit;
?>
