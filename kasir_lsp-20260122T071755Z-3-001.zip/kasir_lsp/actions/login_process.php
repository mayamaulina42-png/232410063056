<?php
// Mulai sesi dan sertakan koneksi database
session_start();
require_once '../includes/koneksi.php';
// Cek apakah data sudah dikirim melalui POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari formulir dan bersihkan
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    // Gunakan Prepared Statements untuk mencegah SQL Injection
    $sql = "SELECT UserID, Username, PasswordHash, Role FROM pengguna WHERE Username = ?";
    if ($stmt = $koneksi->prepare($sql)) {
        // Ikat variabel ke parameter prepared statement
        $stmt->bind_param("s", $param_username);
        // Tetapkan parameter
        $param_username = $username;
        // Eksekusi statement
        if ($stmt->execute()) {
            // Simpan hasil
            $stmt->store_result();
            // Cek apakah username ada
            if ($stmt->num_rows == 1) {
                // Ikat hasil ke variabel
                $stmt->bind_result($id, $username, $hashed_password, $role);
                if ($stmt->fetch()) {
                    // Verifikasi password (asumsi password di database sudah di-hash)
                    // Jika password yang dimasukkan cocok dengan hash di database:
                    if (password_verify($password, $hashed_password)) {
                        // Password benar, inisialisasi sesi
                        $_SESSION['loggedin'] = true;
                        $_SESSION['userid'] = $id;
                        $_SESSION['username'] = $username;
                        $_SESSION['role'] = $role;
                        // Simpan pesan sukses untuk dibawa ke halaman berikutnya
                        $_SESSION['test_success'] = "Login Berhasil! UserID Anda adalah: " . $id;
                        // Arahkan ke halaman dashboard
                        header("Location: ../pages/dashboard.php");
                        exit;
                    } else {
                        // Password tidak valid
                        $_SESSION['login_error'] = "Password yang Anda masukkan salah.";
                    }
                }
            } else {
                // Username tidak ditemukan
                $_SESSION['login_error'] = "Username tidak ditemukan.";
            }
        } else {
            // Error eksekusi
            $_SESSION['login_error'] = "Terjadi kesalahan pada sistem.";
        }
        // Tutup statement
        $stmt->close();
    }
    // Jika ada error, kembali ke halaman login (index.php)
    header("Location: ../index.php");
    exit;
}
// Tutup koneksi
$koneksi->close();
