<?php
// Mendefinisikan konstanta untuk kredensial database
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'kasir_lsp1'); // Ganti dengan nama database yang anda buat

// Membuat koneksi ke database
$koneksi = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Cek koneksi
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

// Opsional: Pengaturan charset ke utf8mb4 untuk mendukung emoji dan karakter khusus
$koneksi->set_charset("utf8mb4");
