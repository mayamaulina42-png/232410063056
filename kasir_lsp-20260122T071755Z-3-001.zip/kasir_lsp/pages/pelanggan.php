<?php
require_once '../includes/koneksi.php';

// Handle tambah/edit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'] ?? '';
    $nama = $_POST['nama'] ?? '';
    $alamat = $_POST['alamat'] ?? '';
    $telepon = $_POST['telepon'] ?? '';
    $jk = $_POST['jenis_kelamin'] ?? '';
    $foto = '';

    // Upload foto
    if (!empty($_FILES['foto']['name'])) {
        $targetDir = "uploads/";
        if (!is_dir($targetDir)) mkdir($targetDir);
        $fileName = time() . "_" . basename($_FILES['foto']['name']);
        $targetFile = $targetDir . $fileName;
        if (move_uploaded_file($_FILES['foto']['tmp_name'], $targetFile)) {
            $foto = $fileName;
        }
    }

    // Tambah baru
    if (empty($id)) {
        $stmt = $koneksi->prepare("INSERT INTO pelanggan (NamaPelanggan, Alamat, NomorTelepon, JenisKelamin, poto) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $nama, $alamat, $telepon, $jk, $foto);
        $stmt->execute();
    }
    // Edit data
    else {
        if ($foto) {
            $stmt = $koneksi->prepare("UPDATE pelanggan SET NamaPelanggan=?, Alamat=?, NomorTelepon=?, JenisKelamin=?, poto=? WHERE PelangganID=?");
            $stmt->bind_param("sssssi", $nama, $alamat, $telepon, $jk, $foto, $id);
        } else {
            $stmt = $koneksi->prepare("UPDATE pelanggan SET NamaPelanggan=?, Alamat=?, NomorTelepon=?, JenisKelamin=? WHERE PelangganID=?");
            $stmt->bind_param("ssssi", $nama, $alamat, $telepon, $jk, $id);
        }
        $stmt->execute();
    }

    header("Location: pelanggan.php");
    exit;
}

// Hapus
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $koneksi->query("DELETE FROM pelanggan WHERE PelangganID='$id'");
    header("Location: pelanggan.php");
    exit;
}

// Ambil data
$data = $koneksi->query("SELECT * FROM pelanggan ORDER BY PelangganID ASC");
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Halaman Pelanggan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <div class="container py-4">
        <h2 class="text-center mb-4">Halaman Pelanggan</h2>

        <!-- Form Tambah -->
        <form method="POST" enctype="multipart/form-data" class="d-flex gap-2 mb-3">
            <input type="hidden" name="id" id="id">
            <input type="text" name="nama" id="nama" class="form-control" placeholder="Nama" required>
            <input type="text" name="alamat" id="alamat" class="form-control" placeholder="Alamat">
            <input type="text" name="telepon" id="telepon" class="form-control" placeholder="Telepon">
            <select name="jenis_kelamin" id="jenis_kelamin" class="form-select">
                <option value="">JK</option>
                <option value="Laki laki">Laki-laki</option>
                <option value="perempuan">Perempuan</option>
            </select>
            <input type="file" name="foto" id="foto" class="form-control" accept="image/*">
            <button type="submit" class="btn btn-primary">Tambah</button>
        </form>

        <!-- Tabel Data -->
        <table class="table table-bordered table-striped align-middle text-center">
            <thead class="table-light">
                <tr>
                    <th>No</th>
                    <th>Nama Pelanggan</th>
                    <th>Alamat</th>
                    <th>Nomor Telepon</th>
                    <th>Jenis Kelamin</th>
                    <th>Foto</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1;
                while ($row = $data->fetch_assoc()): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($row['NamaPelanggan']) ?></td>
                        <td><?= htmlspecialchars($row['Alamat']) ?></td>
                        <td><?= htmlspecialchars($row['NomorTelepon']) ?></td>
                        <td><?= htmlspecialchars($row['JenisKelamin']) ?></td>
                        <td>
                            <?php if ($row['Poto'] && file_exists("uploads/" . $row['Poto'])): ?>
                                <img src="uploads/<?= $row['Poto'] ?>" width="60" class="img-thumbnail">
                            <?php else: ?>
                                <span class="text-muted">Tidak ada foto</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <button class="btn btn-warning btn-sm"
                                onclick="editData('<?= $row['PelangganID'] ?>','<?= htmlspecialchars($row['NamaPelanggan']) ?>','<?= htmlspecialchars($row['Alamat']) ?>','<?= htmlspecialchars($row['NomorTelepon']) ?>','<?= $row['JenisKelamin'] ?>')">
                                Edit
                            </button>
                            <a href="?hapus=<?= $row['PelangganID'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus pelanggan ini?')">Hapus</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <script>
        function editData(id, nama, alamat, telepon, jk) {
            document.getElementById('id').value = id;
            document.getElementById('nama').value = nama;
            document.getElementById('alamat').value = alamat;
            document.getElementById('telepon').value = telepon;
            document.getElementById('jenis_kelamin').value = jk;
        }
    </script>

</body>

</html>